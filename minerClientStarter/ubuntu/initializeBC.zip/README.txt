README

A) prepare the system
	1) donwload and install geth from https://geth.ethereum.org/downloads/
B) start syncronization
	1) unzip the compressed folder in a directory under /home
	2) open a terminal and navigate to the unzipped folder
	3) run the command: "./initBC.sh"
	4) the script execute some simple checks and if everythings ok should start syncronization

more info can be found on: 
	https://github.com/marcuzzu/eth_private_network/blob/master/genesis.json
