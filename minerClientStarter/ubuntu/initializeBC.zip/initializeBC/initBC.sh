#!/bin/bash
gnome-terminal -e 'mc' &
echo "starting"

if ! [ -x "$(command -v geth)" ]; then
  echo 'Error: geth is not installed.' >&2
  exit 1
fi

echo "geth command present"

echo "going to create the folder";

#whit -p if the folder exists do nothing
#BLDirectory="/home/ucalcoin"
#mkdir -p "$BLDirectory"

#echo "folder created=$BLDirectory";




currentBasedir="$(pwd)"
BLDirectory="$currentBasedir"
genesisFile="$currentBasedir/genesis.json"

echo "going to check genesis file present:$genesisFile"

	if [ -f "$genesisFile" ]
	then
		echo "genesis file found"
	else
		echo "genesis file not found"
		exit
	fi

echo "going to init the blockchain from file:\"$genesisFile\""

initCommand2="$(geth --datadir $BLDirectory init $genesisFile)"

#check correct creation....

	if [ -f "$BLDirectory/geth/chaindata/LOG" ]
	then
		echo "chaindata created"
	else
		echo "chaindata not created"
		exit
	fi

#start sincronization 
	
	geth --datadir "$BLDirectory"  --bootnodes "enode://651acaef26675933dadade4dea470e488a98a2fb46ddbfd8bd9ea041482a64f09fee1b70608641b6b3f79f717892aaa65b66a1881c1e0b2787c56f3c4f6be2b0@160.97.62.236:30301,enode://2586d68d2aa4ea654edd675cd3ab49e2b84c48708f7203b6575b58330b58c2007d0b9b1e6bff32e394ae567660bcaba3fd348f2375d54bae4e4082fb7a2bb861@160.97.62.236:30303"

#cat $genesisFile
