README

A) prepare the system
	1) donwload and install geth from https://geth.ethereum.org/downloads/
B) start syncronization
	1) unzip the compressed folder 
	2) navigate to the unzipped folder and go into "initializeBC" folder
	3) double click on iniBC
	4) the script execute some simple checks and if everythings ok should start syncronization

more info can be found on: 
	https://github.com/marcuzzu/eth_private_network